import React, { useState } from 'react';
import { Video, Type, Sliders, Wand2 } from 'lucide-react';

function App() {
  const [text, setText] = useState('');
  const [style, setStyle] = useState('cinematic');
  const [duration, setDuration] = useState(15);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    // Simulate video generation
    setTimeout(() => {
      setIsGenerating(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Video className="w-8 h-8 text-blue-400" />
          <h1 className="text-3xl font-bold">Text to Video Generator</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-gray-800 p-6 rounded-lg shadow-xl">
              <div className="flex items-center gap-2 mb-3">
                <Type className="w-5 h-5 text-blue-400" />
                <h2 className="text-xl font-semibold">Input Text</h2>
              </div>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Describe your video scene..."
                className="w-full h-40 bg-gray-700 text-white rounded-lg p-4 focus:ring-2 focus:ring-blue-400 focus:outline-none"
              />
            </div>

            <div className="bg-gray-800 p-6 rounded-lg shadow-xl">
              <div className="flex items-center gap-2 mb-4">
                <Sliders className="w-5 h-5 text-blue-400" />
                <h2 className="text-xl font-semibold">Settings</h2>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block mb-2">Style</label>
                  <select
                    value={style}
                    onChange={(e) => setStyle(e.target.value)}
                    className="w-full bg-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
                  >
                    <option value="cinematic">Cinematic</option>
                    <option value="animated">Animated</option>
                    <option value="realistic">Realistic</option>
                    <option value="artistic">Artistic</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-2">Duration (seconds)</label>
                  <input
                    type="range"
                    min="5"
                    max="60"
                    value={duration}
                    onChange={(e) => setDuration(Number(e.target.value))}
                    className="w-full"
                  />
                  <span className="text-sm text-gray-400">{duration} seconds</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={!text || isGenerating}
              className="w-full bg-blue-500 hover:bg-blue-600 disabled:bg-gray-600 disabled:cursor-not-allowed py-3 px-6 rounded-lg font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <Wand2 className="w-5 h-5" />
              {isGenerating ? 'Generating...' : 'Generate Video'}
            </button>
          </div>

          <div className="bg-gray-800 p-6 rounded-lg shadow-xl h-full">
            <h2 className="text-xl font-semibold mb-4">Preview</h2>
            {isGenerating ? (
              <div className="flex items-center justify-center h-[400px] bg-gray-700 rounded-lg">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-400"></div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-[400px] bg-gray-700 rounded-lg">
                <p className="text-gray-400">Video preview will appear here</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;